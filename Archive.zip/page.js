document.addEventListener('DOMContentLoaded',() => {

  navigator.serviceWorker.register('/service-worker.js')
     .then(reg => console.log('SW registered!', reg))
     .catch(err => console.log('Boo!', err));

});
